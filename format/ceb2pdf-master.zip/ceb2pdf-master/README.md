# ceb2pdf

Windows命令行工具：将CEB格式的文件转换为PDF格式

# Usage

```
ceb2pdf.exe ceb文件路径  pdf文件路径
```